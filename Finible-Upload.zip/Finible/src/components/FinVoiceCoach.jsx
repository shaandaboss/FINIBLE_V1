import React, { useState, useRef, useEffect } from 'react';
import { Mic, MicOff, Send, Volume2, VolumeX, Loader, MessageCircle } from 'lucide-react';
import { useConversation } from '@elevenlabs/react';
import SharkLogo from './SharkLogo';

const FinVoiceCoach = () => {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "Hey! I'm Sam, your AI Financial Mentor. I'm here to help you understand your money and build the life you want. Click the button below to start talking, or type your message!",
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const messagesEndRef = useRef(null);

  // ElevenLabs Conversation Hook
  const conversation = useConversation({
    onConnect: () => {
      console.log('Connected to Sam');
      setMessages(prev => [...prev, {
        role: 'system',
        content: '🎙️ Voice connection active! Start speaking...',
        timestamp: new Date()
      }]);
    },
    onDisconnect: () => {
      console.log('Disconnected from Sam');
      setMessages(prev => [...prev, {
        role: 'system',
        content: '👋 Voice conversation ended',
        timestamp: new Date()
      }]);
    },
    onMessage: (message) => {
      console.log('Received message:', message);
      if (message.message) {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: message.message,
          timestamp: new Date()
        }]);
      }
      // Capture user speech
      if (message.source === 'user' && message.message) {
        setMessages(prev => [...prev, {
          role: 'user',
          content: message.message,
          timestamp: new Date()
        }]);
      }
    },
    onError: (error) => {
      console.error('Conversation error:', error);
      setMessages(prev => [...prev, {
        role: 'system',
        content: '⚠️ Connection error. Please try again.',
        timestamp: new Date()
      }]);
    },
    // Keep the conversation alive
    config: {
      turn_detection: {
        type: 'server_vad',
      }
    }
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const startConversation = async () => {
    try {
      const agentId = 'agent_2501k20tsbcjeym9t8acz5j5cgw6';

      await conversation.startSession({
        agentId: agentId,
      });
    } catch (error) {
      console.error('Failed to start conversation:', error);
      setMessages(prev => [...prev, {
        role: 'system',
        content: '⚠️ Failed to connect. Please check your microphone permissions and try again.',
        timestamp: new Date()
      }]);
    }
  };

  const stopConversation = async () => {
    await conversation.endSession();
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    conversation.setVolume(isMuted ? 1 : 0);
  };

  const sendTextMessage = () => {
    if (!inputText.trim()) return;

    const userMessage = {
      role: 'user',
      content: inputText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');

    // Send text to conversation if active
    if (conversation.status === 'connected') {
      // You can implement text-to-speech here if needed
      // For now, just display in chat
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendTextMessage();
    }
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-finible-teal/5 via-white to-finible-orange/5 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <SharkLogo className="w-20 h-20 md:w-24 md:h-24" />
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-black mb-4">
            Meet <span className="text-finible-teal">Sam</span>, Your Financial Mentor
          </h1>
          <p className="text-xl md:text-2xl text-gray-700 max-w-3xl mx-auto mb-6">
            Click the button to start talking, or type below
          </p>

          {/* Status Badge */}
          <div className="flex justify-center">
            <div className={`px-6 py-3 rounded-full font-bold text-lg flex items-center space-x-3 ${
              conversation.status === 'connected'
                ? 'bg-green-100 text-green-700 border-2 border-green-400'
                : conversation.status === 'connecting'
                ? 'bg-yellow-100 text-yellow-700 border-2 border-yellow-400'
                : 'bg-gray-100 text-gray-700 border-2 border-gray-300'
            }`}>
              <div className={`w-3 h-3 rounded-full ${
                conversation.status === 'connected' ? 'bg-green-500 animate-pulse' :
                conversation.status === 'connecting' ? 'bg-yellow-500 animate-pulse' : 'bg-gray-400'
              }`}></div>
              <span>
                {conversation.status === 'connected' ? '🎙️ Listening...' :
                 conversation.status === 'connecting' ? '⏳ Connecting...' : '💤 Ready to Talk'}
              </span>
            </div>
          </div>
        </div>

        {/* BIG CIRCULAR VOICE BUTTON */}
        <div className="flex justify-center mb-8">
          {conversation.status === 'connected' ? (
            <button
              onClick={stopConversation}
              className="relative group"
            >
              <div className="w-48 h-48 md:w-64 md:h-64 rounded-full bg-gradient-to-br from-red-500 to-red-600 shadow-2xl shadow-red-500/50 hover:shadow-red-500/70 transition-all duration-300 flex items-center justify-center hover:scale-105 active:scale-95">
                <div className="absolute inset-0 rounded-full bg-white/20 animate-pulse"></div>
                <MicOff className="w-24 h-24 md:w-32 md:h-32 text-white relative z-10" />
              </div>
              <p className="text-2xl font-bold text-red-600 mt-6 text-center">Tap to End</p>
            </button>
          ) : (
            <button
              onClick={startConversation}
              disabled={conversation.status === 'connecting'}
              className="relative group disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <div className="w-48 h-48 md:w-64 md:h-64 rounded-full bg-gradient-to-br from-finible-teal to-finible-orange shadow-2xl shadow-finible-teal/50 hover:shadow-finible-orange/70 transition-all duration-300 flex items-center justify-center hover:scale-105 active:scale-95">
                {conversation.status === 'connecting' ? (
                  <>
                    <div className="absolute inset-0 rounded-full bg-white/30 animate-ping"></div>
                    <Loader className="w-24 h-24 md:w-32 md:h-32 text-white animate-spin relative z-10" />
                  </>
                ) : (
                  <>
                    <div className="absolute inset-0 rounded-full bg-white/10 group-hover:bg-white/20 transition-all"></div>
                    <Mic className="w-24 h-24 md:w-32 md:h-32 text-white relative z-10" />
                  </>
                )}
              </div>
              <p className="text-2xl font-bold bg-gradient-to-r from-finible-teal to-finible-orange bg-clip-text text-transparent mt-6 text-center">
                {conversation.status === 'connecting' ? 'Connecting...' : 'Tap to Talk'}
              </p>
            </button>
          )}
        </div>

        {/* Mute Button */}
        {conversation.status === 'connected' && (
          <div className="flex justify-center mb-8">
            <button
              onClick={toggleMute}
              className={`px-6 py-3 rounded-full font-bold transition-all flex items-center space-x-3 ${
                isMuted
                  ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  : 'bg-finible-teal text-white hover:bg-opacity-90'
              }`}
            >
              {isMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
              <span>{isMuted ? 'Unmuted' : 'Mute Sam'}</span>
            </button>
          </div>
        )}

        {/* Main Chat Interface */}
        <div className="bg-white rounded-3xl shadow-xl border-4 border-finible-teal/20 overflow-hidden max-w-5xl mx-auto">

          {/* Messages Container */}
          <div className="h-[400px] overflow-y-auto p-6 space-y-4 bg-gradient-to-b from-white to-gray-50">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[75%] rounded-3xl px-6 py-4 shadow-lg ${
                    message.role === 'user'
                      ? 'bg-gradient-to-br from-finible-teal to-finible-teal/80 text-white'
                      : message.role === 'assistant'
                      ? 'bg-white border-3 border-finible-orange text-gray-900'
                      : 'bg-gradient-to-r from-finible-orange/20 to-finible-teal/20 border-2 border-finible-orange/50 text-gray-800 text-center font-medium'
                  }`}
                >
                  {message.role === 'assistant' && (
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-finible-teal to-finible-orange rounded-full flex items-center justify-center shadow-md">
                        <span className="text-white font-bold text-lg">S</span>
                      </div>
                      <span className="font-bold text-finible-teal text-lg">Sam</span>
                    </div>
                  )}
                  <p className="text-lg leading-relaxed">{message.content}</p>
                  <p className={`text-xs mt-2 ${message.role === 'user' ? 'text-white/80' : 'text-gray-400'}`}>
                    {formatTime(message.timestamp)}
                  </p>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Text Input */}
          <div className="bg-gradient-to-r from-finible-teal/5 to-finible-orange/5 border-t-4 border-finible-teal/20 p-6">
            <div className="flex items-center space-x-4">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type a message to Sam..."
                className="flex-1 px-6 py-4 bg-white rounded-full focus:outline-none focus:ring-4 focus:ring-finible-teal/30 text-lg border-2 border-gray-200 shadow-sm"
              />
              <button
                onClick={sendTextMessage}
                disabled={!inputText.trim()}
                className="p-4 bg-gradient-to-br from-finible-teal to-finible-orange text-white rounded-full hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
              >
                <Send className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Tips Section */}
        <div className="mt-12 grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <div className="bg-white rounded-3xl p-8 shadow-lg border-2 border-gray-100 text-center hover:shadow-xl hover:border-finible-teal transition-all">
            <div className="w-16 h-16 bg-finible-teal/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mic className="w-10 h-10 text-finible-teal" />
            </div>
            <h3 className="text-2xl font-bold text-black mb-3">Speak Naturally</h3>
            <p className="text-gray-600 text-lg">Talk to Sam like you would a friend. No financial jargon required.</p>
          </div>
          <div className="bg-finible-orange rounded-3xl p-8 shadow-lg text-center hover:shadow-xl transition-all border-2 border-finible-orange">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4">
              <Volume2 className="w-10 h-10 text-finible-orange" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">Listen & Learn</h3>
            <p className="text-white/95 text-lg">Sam explains complex financial concepts in simple terms.</p>
          </div>
          <div className="bg-white rounded-3xl p-8 shadow-lg border-2 border-gray-100 text-center hover:shadow-xl hover:border-finible-teal transition-all">
            <div className="w-16 h-16 bg-finible-teal/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="w-10 h-10 text-finible-teal" />
            </div>
            <h3 className="text-2xl font-bold text-black mb-3">Type Anytime</h3>
            <p className="text-gray-600 text-lg">Prefer texting? You can chat with Sam via text too.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinVoiceCoach;
