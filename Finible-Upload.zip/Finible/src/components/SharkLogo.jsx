import React from 'react';

const SharkLogo = ({ className = "w-12 h-12", animated = false }) => {
  // Use the main FinibleAI logo with transparent background everywhere
  const logoSrc = "/finible-main-logo.png";

  return (
    <div className={`${className} ${animated ? 'animate-glow' : ''} flex items-center justify-center`}>
      <img
        src={logoSrc}
        alt="Finible Logo"
        className="w-full h-full object-contain"
      />
    </div>
  );
};

export default SharkLogo;
