import React, { useState } from 'react';
import { Menu, X, MessageCircle, Target, TrendingUp, Award, Play, ChevronRight } from 'lucide-react';
import SharkLogo from './components/SharkLogo';
import FinVoiceCoach from './components/FinVoiceCoach';

const Finible = () => {
  const [currentPage, setCurrentPage] = useState('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Navigation Component
  const Navigation = () => (
    <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm shadow-sm z-50">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        <div className="flex justify-between items-center h-24">
          {/* Logo */}
          <div className="flex items-center cursor-pointer group" onClick={() => setCurrentPage('home')}>
            <img src="/finible-text-logo.png" alt="Finible" className="h-16 w-auto object-contain transition-transform group-hover:scale-105" />
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-2">
            <button
              onClick={() => setCurrentPage('home')}
              className={`text-lg font-semibold px-5 py-2.5 rounded-xl transition-all ${
                currentPage === 'home'
                  ? 'text-finible-teal bg-finible-teal/10'
                  : 'text-gray-700 hover:text-finible-teal hover:bg-gray-50'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => setCurrentPage('features')}
              className={`text-lg font-semibold px-5 py-2.5 rounded-xl transition-all ${
                currentPage === 'features'
                  ? 'text-finible-teal bg-finible-teal/10'
                  : 'text-gray-700 hover:text-finible-teal hover:bg-gray-50'
              }`}
            >
              Explore
            </button>
            <button
              onClick={() => setCurrentPage('pricing')}
              className={`text-lg font-semibold px-5 py-2.5 rounded-xl transition-all ${
                currentPage === 'pricing'
                  ? 'text-finible-teal bg-finible-teal/10'
                  : 'text-gray-700 hover:text-finible-teal hover:bg-gray-50'
              }`}
            >
              Pricing
            </button>
            <button
              onClick={() => setCurrentPage('about')}
              className={`text-lg font-semibold px-5 py-2.5 rounded-xl transition-all ${
                currentPage === 'about'
                  ? 'text-finible-teal bg-finible-teal/10'
                  : 'text-gray-700 hover:text-finible-teal hover:bg-gray-50'
              }`}
            >
              About
            </button>
            <button
              onClick={() => setCurrentPage('app')}
              className="ml-4 bg-gradient-to-r from-finible-teal to-finible-orange text-white px-8 py-3 rounded-xl hover:shadow-lg hover:scale-105 transition-all font-bold text-lg"
            >
              Get Started
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-gray-700 hover:text-finible-teal p-2"
            >
              {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden pb-6 pt-2">
            <div className="flex flex-col space-y-2">
              <button
                onClick={() => { setCurrentPage('home'); setMobileMenuOpen(false); }}
                className={`text-left text-lg font-semibold px-4 py-3 rounded-xl transition-all ${
                  currentPage === 'home'
                    ? 'text-finible-teal bg-finible-teal/10'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => { setCurrentPage('features'); setMobileMenuOpen(false); }}
                className={`text-left text-lg font-semibold px-4 py-3 rounded-xl transition-all ${
                  currentPage === 'features'
                    ? 'text-finible-teal bg-finible-teal/10'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                Explore
              </button>
              <button
                onClick={() => { setCurrentPage('pricing'); setMobileMenuOpen(false); }}
                className={`text-left text-lg font-semibold px-4 py-3 rounded-xl transition-all ${
                  currentPage === 'pricing'
                    ? 'text-finible-teal bg-finible-teal/10'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                Pricing
              </button>
              <button
                onClick={() => { setCurrentPage('about'); setMobileMenuOpen(false); }}
                className={`text-left text-lg font-semibold px-4 py-3 rounded-xl transition-all ${
                  currentPage === 'about'
                    ? 'text-finible-teal bg-finible-teal/10'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                About
              </button>
              <button
                onClick={() => { setCurrentPage('app'); setMobileMenuOpen(false); }}
                className="bg-gradient-to-r from-finible-teal to-finible-orange text-white px-6 py-3 rounded-xl hover:shadow-lg transition-all font-bold text-lg text-center mt-2"
              >
                Get Started
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );

  // Home Page
  const HomePage = () => (
    <div className="min-h-screen bg-white pt-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden min-h-screen flex items-center">
        {/* More fluid ocean gradient - animated */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-200/20 via-blue-300/20 to-finible-teal/30"></div>
          <div className="absolute bottom-0 left-0 right-0 h-[80%] bg-gradient-to-t from-blue-500/30 via-cyan-400/20 to-transparent blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-[60%] h-[60%] bg-gradient-to-tl from-finible-teal/40 to-transparent blur-2xl rounded-full"></div>
          <div className="absolute bottom-0 left-0 w-[50%] h-[50%] bg-gradient-to-tr from-blue-400/30 to-transparent blur-2xl rounded-full"></div>
          {/* Fade to white at bottom */}
          <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 w-full relative z-10">
          <div className="flex flex-col items-center text-center space-y-16">
            {/* Logo */}
            <div className="flex justify-center items-center mb-16">
              <SharkLogo className="w-72 h-72 md:w-96 md:h-96 lg:w-[28rem] lg:h-[28rem]" animated={false} />
            </div>

            {/* Text Content - Speakl-style */}
            <div className="max-w-6xl mx-auto space-y-10">
              <h1 className="text-6xl md:text-8xl lg:text-9xl font-bold leading-tight">
                <span className="text-black">Your Money,</span>
                <br />
                <span className="text-finible-teal">Reimagined</span>
              </h1>
              <p className="text-2xl md:text-3xl lg:text-4xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
                Build financial confidence with AI-powered coaching that adapts to your goals, lifestyle, and dreams. Transform stress into clarity.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center mt-8">
              <button
                onClick={() => setCurrentPage('app')}
                className="bg-finible-orange text-white px-12 py-5 rounded-xl text-xl font-bold hover:bg-opacity-90 transition-all flex items-center justify-center space-x-3 shadow-2xl shadow-finible-orange/30"
              >
                <Play size={24} />
                <span>Start Your Journey</span>
              </button>
              <button
                onClick={() => setCurrentPage('about')}
                className="bg-white border-2 border-finible-teal text-finible-teal px-12 py-5 rounded-xl text-xl font-bold hover:bg-finible-teal hover:text-white transition-all flex items-center justify-center space-x-3 shadow-2xl"
              >
                <span>Learn More</span>
                <ChevronRight size={24} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-24 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-black mb-8">The Problem</h2>
            <p className="text-2xl md:text-3xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
              Young adults today often feel lost when it comes to managing money — they want to save, invest, and live their dream lifestyle, but don't know how to get there.
            </p>
          </div>
          <div className="bg-gray-50 rounded-3xl border-4 border-finible-orange p-12 md:p-16 text-center flex justify-center items-center">
            <p className="text-2xl md:text-3xl lg:text-4xl text-gray-900 leading-relaxed font-medium max-w-5xl">
              They're taught how to <span className="font-bold text-finible-teal">make money</span>,<br className="hidden md:block" /> but not how to <span className="font-bold text-finible-orange">live with it</span>.
            </p>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="relative py-24 bg-gray-50 overflow-hidden">
        {/* Ocean gradient at bottom */}
        <div className="absolute inset-0">
          <div className="absolute bottom-0 left-0 right-0 h-[60%] bg-gradient-to-t from-blue-500/20 via-cyan-400/15 to-transparent blur-2xl"></div>
          <div className="absolute bottom-0 right-0 w-[50%] h-[50%] bg-gradient-to-tl from-finible-teal/30 to-transparent blur-xl rounded-full"></div>
          <div className="absolute bottom-0 left-0 w-[40%] h-[40%] bg-gradient-to-tr from-blue-400/20 to-transparent blur-xl rounded-full"></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold text-black mb-6">The Solution</h2>
            <p className="text-2xl md:text-3xl text-gray-700 max-w-4xl mx-auto leading-relaxed mb-4">
              Finance Made Possible
            </p>
            <p className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto">
              We make financial learning fun, personal, and actionable.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
            {[
              {
                icon: <MessageCircle className="w-12 h-12 text-finible-teal" />,
                title: 'AI Voice Coach',
                description: 'Chat with Sam, your personal AI financial mentor who understands your lifestyle'
              },
              {
                icon: <Target className="w-12 h-12 text-finible-orange" />,
                title: 'Progress Rings',
                description: 'Track your Freedom, Safety, and Growth with Apple Fitness-style rings'
              },
              {
                icon: <TrendingUp className="w-12 h-12 text-finible-teal" />,
                title: 'Visual Roadmap',
                description: 'See exactly how to get from your current lifestyle to your dream life'
              },
              {
                icon: <Award className="w-12 h-12 text-finible-orange" />,
                title: 'Gamification',
                description: 'Earn achievements, build streaks, and level up your financial wellness'
              }
            ].map((feature, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 hover:border-finible-teal hover:shadow-xl border-2 border-gray-200 transition-all text-center">
                <div className="mb-4 flex justify-center">{feature.icon}</div>
                <h3 className="text-2xl font-bold text-black mb-4">{feature.title}</h3>
                <p className="text-lg text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">Ready to Transform Your Financial Future?</h2>
          <p className="text-xl mb-8 text-gray-700">
            Join thousands of young adults building confidence with money
          </p>
          <button
            onClick={() => setCurrentPage('app')}
            className="bg-finible-orange text-white px-10 py-4 rounded-lg text-lg font-bold hover:bg-opacity-90 transition-all shadow-xl"
          >
            Get Started for Free
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-100 text-gray-900 py-12 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-4 md:mb-0">
              <SharkLogo className="w-8 h-8" />
              <span className="text-xl font-bold">Finible</span>
            </div>
            <p className="text-gray-600 text-sm">
              © 2025 Finible. Making financial wellness accessible for young adults.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );

  // Features Page
  const FeaturesPage = () => (
    <div className="min-h-screen bg-white pt-24 pb-12">
      <div className="w-full px-8 sm:px-12 lg:px-20">
        {/* Hero Section */}
        <div className="text-center mb-20 max-w-6xl mx-auto">
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-black mb-6">
            Everything You Need to <span className="text-finible-teal">Master Money</span>
          </h1>
          <p className="text-2xl md:text-3xl text-gray-700">
            Powerful tools designed to make financial wellness simple, visual, and engaging
          </p>
        </div>

        {/* Meet Fin - The Mascot */}
        <section className="mb-32 bg-gradient-to-br from-finible-teal/10 to-finible-orange/10 rounded-3xl p-12 lg:p-16">
          <div className="grid md:grid-cols-2 gap-16 items-center max-w-7xl mx-auto">
            <div className="order-2 md:order-1">
              <div className="flex justify-center">
                <img
                  src="/Fin-TheShark.png"
                  alt="Fin the Shark - Finible Mascot"
                  className="w-full max-w-lg h-auto object-contain"
                />
              </div>
            </div>
            <div className="order-1 md:order-2">
              <div className="inline-block bg-finible-teal text-white px-4 py-2 rounded-full font-bold mb-6">
                MEET YOUR GUIDE
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">
                This is <span className="text-finible-teal">Fin</span>, Your Friendly Companion
              </h2>
              <p className="text-xl text-gray-700 mb-6 leading-relaxed">
                <span className="font-bold text-finible-teal">Fin the Shark</span> is your financial wellness companion—your friendly guide who's always in your corner. Fin is here to cheer you on, celebrate your wins, and keep you motivated on your money journey.
              </p>

              <div className="bg-white rounded-2xl p-6 border-2 border-finible-orange mb-6">
                <h3 className="text-2xl font-bold text-black mb-4">Fin vs Sam: What's the Difference?</h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 rounded-full bg-finible-teal flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold">F</span>
                    </div>
                    <div>
                      <p className="font-bold text-black text-lg">Fin = Your Mascot</p>
                      <p className="text-gray-600">The friendly shark who represents Finible. Fin celebrates your achievements, tracks your streaks, and makes learning fun with gamification.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 rounded-full bg-finible-orange flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-white font-bold">S</span>
                    </div>
                    <div>
                      <p className="font-bold text-black text-lg">Sam = Your AI Financial Mentor</p>
                      <p className="text-gray-600">The intelligent AI coach you actually talk to. Sam answers your questions, gives personalized advice, and helps you build your financial plan.</p>
                    </div>
                  </div>
                </div>
              </div>

              <p className="text-lg text-gray-700 italic">
                Think of it this way: <span className="font-bold text-finible-teal">Fin</span> is your cheerleader, <span className="font-bold text-finible-orange">Sam</span> is your coach.
              </p>
            </div>
          </div>
        </section>

        {/* Feature 1: Financial Health Score */}
        <section className="mb-32 max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className="order-2 md:order-1">
              <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-3xl p-12 flex items-center justify-center min-h-[500px]">
                {/* Health Score visualization */}
                <div className="text-center">
                  <div className="relative w-64 h-64 mx-auto mb-6">
                    <svg className="w-full h-full transform -rotate-90">
                      <circle
                        cx="128"
                        cy="128"
                        r="100"
                        stroke="#e5e7eb"
                        strokeWidth="20"
                        fill="none"
                      />
                      <circle
                        cx="128"
                        cy="128"
                        r="100"
                        stroke="url(#gradient)"
                        strokeWidth="20"
                        fill="none"
                        strokeDasharray="628"
                        strokeDashoffset="125"
                        strokeLinecap="round"
                      />
                      <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="#06cad6" />
                          <stop offset="100%" stopColor="#ff7e26" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <p className="text-6xl font-bold text-black">82</p>
                        <p className="text-lg text-gray-600 mt-1">Healthy</p>
                      </div>
                    </div>
                  </div>
                  <p className="text-xl font-bold text-black">Your Financial Health Score</p>
                </div>
              </div>
            </div>
            <div className="order-1 md:order-2">
              <div className="inline-block bg-finible-teal/10 text-finible-teal px-4 py-2 rounded-full font-bold mb-6">
                KNOW YOUR HEALTH
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">
                Financial Health Score
              </h2>
              <p className="text-xl text-gray-700 mb-8 leading-relaxed">
                Get a real-time snapshot of your overall financial wellness with a single, easy-to-understand score from 0-100.
              </p>

              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <ChevronRight className="w-6 h-6 text-finible-teal mt-1" />
                  <div>
                    <p className="font-bold text-black text-lg">Daily Updates</p>
                    <p className="text-gray-600">Your score updates automatically as your financial situation changes</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <ChevronRight className="w-6 h-6 text-finible-teal mt-1" />
                  <div>
                    <p className="font-bold text-black text-lg">Personalized Insights</p>
                    <p className="text-gray-600">Understand exactly what's helping or hurting your score</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <ChevronRight className="w-6 h-6 text-finible-teal mt-1" />
                  <div>
                    <p className="font-bold text-black text-lg">Track Progress</p>
                    <p className="text-gray-600">Watch your score improve as you build better financial habits</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Feature 2: Financial Archetype */}
        <section className="mb-32 bg-gradient-to-br from-finible-orange/5 to-finible-teal/5 rounded-3xl p-12 lg:p-16">
          <div className="grid md:grid-cols-2 gap-16 items-center max-w-7xl mx-auto">
            <div>
              <div className="inline-block bg-finible-orange/10 text-finible-orange px-4 py-2 rounded-full font-bold mb-6">
                DISCOVER YOUR TYPE
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">
                Your Financial Archetype
              </h2>
              <p className="text-xl text-gray-700 mb-8 leading-relaxed">
                Everyone has a unique money personality. Discover yours and get personalized strategies that actually work for you.
              </p>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white rounded-2xl p-6 text-center shadow-md">
                  <div className="text-4xl mb-2">🎯</div>
                  <p className="font-bold text-black">The Planner</p>
                  <p className="text-sm text-gray-600 mt-1">Strategic & Future-Focused</p>
                </div>
                <div className="bg-white rounded-2xl p-6 text-center shadow-md">
                  <div className="text-4xl mb-2">🚀</div>
                  <p className="font-bold text-black">The Adventurer</p>
                  <p className="text-sm text-gray-600 mt-1">Bold & Risk-Taking</p>
                </div>
                <div className="bg-white rounded-2xl p-6 text-center shadow-md">
                  <div className="text-4xl mb-2">🛡️</div>
                  <p className="font-bold text-black">The Guardian</p>
                  <p className="text-sm text-gray-600 mt-1">Cautious & Security-Minded</p>
                </div>
                <div className="bg-white rounded-2xl p-6 text-center shadow-md">
                  <div className="text-4xl mb-2">⚖️</div>
                  <p className="font-bold text-black">The Balancer</p>
                  <p className="text-sm text-gray-600 mt-1">Moderate & Balanced</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-xl">
              <div className="border-l-4 border-finible-orange pl-6">
                <h3 className="text-2xl font-bold text-black mb-4">Why It Matters</h3>
                <ul className="space-y-4 text-gray-700">
                  <li className="flex items-start space-x-3">
                    <span className="text-finible-orange font-bold">•</span>
                    <span>Get advice tailored to your money personality, not generic tips</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <span className="text-finible-orange font-bold">•</span>
                    <span>Understand your financial strengths and blind spots</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <span className="text-finible-orange font-bold">•</span>
                    <span>Build strategies that align with how you naturally think about money</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <span className="text-finible-orange font-bold">•</span>
                    <span>Sam adapts conversations based on your archetype</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Feature 3: Progress Rings */}
        <section className="mb-32 max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-block bg-finible-teal/10 text-finible-teal px-4 py-2 rounded-full font-bold mb-6">
                TRACK YOUR PROGRESS
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">
                Progress Rings
              </h2>
              <p className="text-xl text-gray-700 mb-8 leading-relaxed">
                Track your financial wellness across three essential dimensions with beautiful Apple Fitness-style rings.
              </p>

              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-black mb-2">Freedom Ring</h3>
                    <p className="text-gray-600 text-lg">Monthly spending flexibility and cash flow health</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-black mb-2">Safety Ring</h3>
                    <p className="text-gray-600 text-lg">Emergency fund and financial security progress</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-full bg-finible-teal flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-black mb-2">Growth Ring</h3>
                    <p className="text-gray-600 text-lg">Investment and wealth-building momentum</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-3xl p-12 flex items-center justify-center min-h-[500px]">
              {/* Placeholder for rings visualization */}
              <div className="relative w-80 h-80">
                <div className="absolute inset-0 rounded-full border-[20px] border-green-500/30"></div>
                <div className="absolute inset-8 rounded-full border-[20px] border-blue-500/30"></div>
                <div className="absolute inset-16 rounded-full border-[20px] border-finible-teal/30"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-6xl font-bold text-black">78%</p>
                    <p className="text-xl text-gray-600 mt-2">Overall Score</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Feature 2: Visual Roadmap */}
        <section className="mb-32 bg-gradient-to-br from-finible-teal/5 to-finible-orange/5 rounded-3xl p-12 lg:p-16">
          <div className="grid md:grid-cols-2 gap-16 items-center max-w-7xl mx-auto">
            <div className="order-2 md:order-1">
              <div className="bg-white rounded-3xl p-8 shadow-xl">
                {/* Roadmap visualization placeholder */}
                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 rounded-full bg-finible-teal text-white flex items-center justify-center font-bold">1</div>
                    <div className="flex-1">
                      <div className="h-3 bg-finible-teal rounded-full"></div>
                      <p className="text-sm text-gray-600 mt-1">Current Lifestyle</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 rounded-full bg-finible-orange text-white flex items-center justify-center font-bold">2</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-200 rounded-full w-3/4"></div>
                      <p className="text-sm text-gray-600 mt-1">Build Safety Net</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 rounded-full bg-gray-300 text-white flex items-center justify-center font-bold">3</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-200 rounded-full w-1/2"></div>
                      <p className="text-sm text-gray-600 mt-1">Start Investing</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 rounded-full bg-gray-300 text-white flex items-center justify-center font-bold">4</div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-200 rounded-full w-1/3"></div>
                      <p className="text-sm text-gray-600 mt-1">Dream Lifestyle</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="order-1 md:order-2">
              <div className="inline-block bg-finible-orange/10 text-finible-orange px-4 py-2 rounded-full font-bold mb-6">
                SEE YOUR PATH
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">
                Visual Roadmap
              </h2>
              <p className="text-xl text-gray-700 mb-6 leading-relaxed">
                See exactly how to get from your current lifestyle to your dream life with a clear, step-by-step visual roadmap.
              </p>
              <ul className="space-y-4 text-lg text-gray-700">
                <li className="flex items-center space-x-3">
                  <ChevronRight className="w-6 h-6 text-finible-teal" />
                  <span>Personalized milestones based on your goals</span>
                </li>
                <li className="flex items-center space-x-3">
                  <ChevronRight className="w-6 h-6 text-finible-teal" />
                  <span>Timeline projections for major life events</span>
                </li>
                <li className="flex items-center space-x-3">
                  <ChevronRight className="w-6 h-6 text-finible-teal" />
                  <span>Track progress toward each milestone</span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Feature 3: Gamification */}
        <section className="mb-32 max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-block bg-finible-teal/10 text-finible-teal px-4 py-2 rounded-full font-bold mb-6">
                MAKE IT FUN
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">
                Gamification
              </h2>
              <p className="text-xl text-gray-700 mb-8 leading-relaxed">
                Stay motivated with achievements, streaks, and level-ups. Financial wellness has never been this engaging.
              </p>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gradient-to-br from-finible-teal to-finible-teal/80 rounded-2xl p-6 text-white text-center">
                  <Award className="w-12 h-12 mx-auto mb-3" />
                  <p className="font-bold text-3xl">12</p>
                  <p className="text-sm opacity-90">Achievements</p>
                </div>
                <div className="bg-gradient-to-br from-finible-orange to-finible-orange/80 rounded-2xl p-6 text-white text-center">
                  <Target className="w-12 h-12 mx-auto mb-3" />
                  <p className="font-bold text-3xl">7</p>
                  <p className="text-sm opacity-90">Day Streak</p>
                </div>
                <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-6 text-white text-center">
                  <TrendingUp className="w-12 h-12 mx-auto mb-3" />
                  <p className="font-bold text-3xl">Level 5</p>
                  <p className="text-sm opacity-90">Money Master</p>
                </div>
                <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white text-center">
                  <MessageCircle className="w-12 h-12 mx-auto mb-3" />
                  <p className="font-bold text-3xl">23</p>
                  <p className="text-sm opacity-90">Convos with Sam</p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-3xl p-12">
              <h3 className="text-2xl font-bold text-black mb-6">Recent Achievements</h3>
              <div className="space-y-4">
                <div className="bg-white rounded-xl p-4 flex items-center space-x-4 shadow-sm">
                  <div className="w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center">
                    <Award className="w-6 h-6 text-yellow-900" />
                  </div>
                  <div>
                    <p className="font-bold text-black">First Budget Created</p>
                    <p className="text-sm text-gray-600">Completed 2 days ago</p>
                  </div>
                </div>
                <div className="bg-white rounded-xl p-4 flex items-center space-x-4 shadow-sm">
                  <div className="w-12 h-12 bg-finible-teal rounded-full flex items-center justify-center">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-black">Week Streak Master</p>
                    <p className="text-sm text-gray-600">Completed 1 week ago</p>
                  </div>
                </div>
                <div className="bg-white rounded-xl p-4 flex items-center space-x-4 shadow-sm opacity-50">
                  <div className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-gray-600" />
                  </div>
                  <div>
                    <p className="font-bold text-black">Investment Beginner</p>
                    <p className="text-sm text-gray-600">Locked - Start investing to unlock</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Feature 4: AI Voice Coach */}
        <section className="bg-gradient-to-br from-finible-teal to-finible-orange rounded-3xl p-12 lg:p-16 text-white text-center max-w-7xl mx-auto">
          <MessageCircle className="w-20 h-20 mx-auto mb-6" />
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Meet Sam, Your AI Financial Mentor
          </h2>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto opacity-95">
            Have real conversations about money. Sam understands your lifestyle, your goals, and speaks your language—no jargon, just clarity.
          </p>
          <button
            onClick={() => setCurrentPage('app')}
            className="bg-white text-finible-teal px-8 py-4 rounded-full text-xl font-bold hover:bg-gray-100 transition-all shadow-xl"
          >
            Start Talking to Sam
          </button>
        </section>
      </div>
    </div>
  );

  // Pricing Page (Placeholder)
  const PricingPage = () => (
    <div className="min-h-screen bg-white pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-black mb-4">Simple, Transparent Pricing</h1>
          <p className="text-xl text-gray-600">Choose the plan that fits your financial wellness journey</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Free Tier */}
          <div className="bg-white border-2 border-gray-200 rounded-2xl p-8 hover:shadow-xl transition-all">
            <h3 className="text-2xl font-bold text-black mb-2">Free</h3>
            <p className="text-4xl font-bold text-finible-teal mb-6">$0<span className="text-lg text-gray-500">/mo</span></p>
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-finible-teal mr-2 mt-1" />
                <span className="text-gray-700">Basic AI chat</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-finible-teal mr-2 mt-1" />
                <span className="text-gray-700">Lifestyle mapping</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-finible-teal mr-2 mt-1" />
                <span className="text-gray-700">Basic budgeting tools</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-finible-teal mr-2 mt-1" />
                <span className="text-gray-700">Retirement dashboard</span>
              </li>
            </ul>
            <button
              onClick={() => setCurrentPage('app')}
              className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-200 transition-all"
            >
              Get Started
            </button>
          </div>

          {/* Plus Tier */}
          <div className="bg-finible-teal text-white border-2 border-finible-teal rounded-2xl p-8 hover:shadow-xl transition-all transform scale-105">
            <div className="bg-finible-orange text-white text-xs font-bold px-3 py-1 rounded-full inline-block mb-3">POPULAR</div>
            <h3 className="text-2xl font-bold mb-2">Plus</h3>
            <p className="text-4xl font-bold mb-6">$9.99<span className="text-lg opacity-75">/mo</span></p>
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-white mr-2 mt-1" />
                <span>Everything in Free</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-white mr-2 mt-1" />
                <span>Advanced visualizations</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-white mr-2 mt-1" />
                <span>Wealth projections</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-white mr-2 mt-1" />
                <span>Investment simulations</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-white mr-2 mt-1" />
                <span>Educational content library</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-white mr-2 mt-1" />
                <span>Weekly financial nudges</span>
              </li>
            </ul>
            <button
              onClick={() => setCurrentPage('app')}
              className="w-full bg-white text-finible-teal py-3 rounded-lg font-semibold hover:bg-gray-100 transition-all"
            >
              Start Free Trial
            </button>
          </div>

          {/* Premium Tier */}
          <div className="bg-white border-2 border-finible-orange rounded-2xl p-8 hover:shadow-xl transition-all">
            <h3 className="text-2xl font-bold text-black mb-2">Premium</h3>
            <p className="text-4xl font-bold text-finible-orange mb-6">$24.99<span className="text-lg text-gray-500">/mo</span></p>
            <ul className="space-y-3 mb-8">
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-finible-orange mr-2 mt-1" />
                <span className="text-gray-700">Everything in Plus</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-finible-orange mr-2 mt-1" />
                <span className="text-gray-700">Real financial coach access</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-finible-orange mr-2 mt-1" />
                <span className="text-gray-700">Community events</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-finible-orange mr-2 mt-1" />
                <span className="text-gray-700">Priority support</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-finible-orange mr-2 mt-1" />
                <span className="text-gray-700">Advanced analytics</span>
              </li>
              <li className="flex items-start">
                <ChevronRight className="w-5 h-5 text-finible-orange mr-2 mt-1" />
                <span className="text-gray-700">Custom goal planning</span>
              </li>
            </ul>
            <button
              onClick={() => setCurrentPage('app')}
              className="w-full bg-finible-orange text-white py-3 rounded-lg font-semibold hover:bg-opacity-90 transition-all"
            >
              Go Premium
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // About Page
  const AboutPage = () => (
    <div className="min-h-screen bg-white pt-24 pb-12">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-br from-finible-teal/10 via-white to-finible-orange/10 py-20 mb-20">
        <div className="max-w-6xl mx-auto px-8 sm:px-12 lg:px-20 text-center">
          <div className="inline-block bg-finible-teal text-white px-6 py-2 rounded-full font-bold mb-6">
            OUR STORY
          </div>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-black mb-8">
            About <span className="text-finible-teal">Finible</span>
          </h1>
          <p className="text-2xl md:text-3xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
            Redefining financial wellness for the next generation
          </p>
        </div>
      </div>

      <div className="w-full px-8 sm:px-12 lg:px-20">
        {/* Mission Section */}
        <section className="mb-32 max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-block bg-finible-orange/10 text-finible-orange px-4 py-2 rounded-full font-bold mb-6">
                OUR MISSION
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">
                Making Money Wellness <span className="text-finible-teal">Accessible</span>
              </h2>
              <p className="text-xl text-gray-700 leading-relaxed mb-6">
                We're pioneering the world's first AI-powered financial therapy platform that makes financial wellness as emotionally intuitive and accessible as mental and physical health.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Young adults deserve better than spreadsheets and jargon. They need a friend, a coach, and a cheerleader all in one.
              </p>
            </div>
            <div className="bg-gradient-to-br from-finible-teal/20 to-finible-orange/20 rounded-3xl p-12 flex items-center justify-center min-h-[400px]">
              <div className="text-center">
                <div className="w-32 h-32 mx-auto mb-6 bg-white rounded-full flex items-center justify-center shadow-xl">
                  <Target className="w-16 h-16 text-finible-teal" />
                </div>
                <p className="text-2xl font-bold text-black">Empowering 1M+ Young Adults</p>
                <p className="text-lg text-gray-600 mt-2">To master their financial future</p>
              </div>
            </div>
          </div>
        </section>

        {/* What Makes Us Different */}
        <section className="mb-32 max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">What Makes Us Different</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're not your typical budgeting app. We're a complete financial wellness platform.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Target className="w-10 h-10" />,
                title: 'Starts with YOU',
                description: 'Your lifestyle, your habits, your goals — not spreadsheets and boring numbers.',
                color: 'finible-teal'
              },
              {
                icon: <MessageCircle className="w-10 h-10" />,
                title: 'AI-Powered Conversations',
                description: 'Uncover your money mindset through natural voice and chat-based conversations with Sam.',
                color: 'finible-orange'
              },
              {
                icon: <TrendingUp className="w-10 h-10" />,
                title: 'Visual & Interactive',
                description: 'See your current lifestyle mapped against your financial future through timelines and visuals.',
                color: 'finible-teal'
              },
              {
                icon: <Award className="w-10 h-10" />,
                title: 'Gamification That Works',
                description: 'Stay engaged with personalized progress rings, achievements, and smart nudges.',
                color: 'finible-orange'
              },
              {
                icon: <TrendingUp className="w-10 h-10" />,
                title: 'Smart Investing',
                description: 'Not just saving advice — we help you actually build wealth intelligently.',
                color: 'finible-teal'
              },
              {
                icon: <Play className="w-10 h-10" />,
                title: 'Action-Oriented',
                description: 'Every conversation leads to clear, achievable next steps tailored to your life.',
                color: 'finible-orange'
              }
            ].map((item, index) => (
              <div key={index} className="bg-white rounded-3xl p-8 shadow-lg border-2 border-gray-100 hover:border-finible-teal hover:shadow-xl transition-all">
                <div className={`w-16 h-16 rounded-full bg-${item.color}/10 flex items-center justify-center mb-6 text-${item.color}`}>
                  {item.icon}
                </div>
                <h3 className="text-2xl font-bold text-black mb-4">{item.title}</h3>
                <p className="text-gray-600 text-lg leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* The Team/Values */}
        <section className="mb-32 bg-gradient-to-br from-finible-teal to-finible-orange rounded-3xl p-12 lg:p-16 text-white text-center max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-8">Our Vision</h2>
          <p className="text-2xl md:text-3xl mb-8 max-w-4xl mx-auto leading-relaxed font-medium">
            We help young adults bridge the gap between how they live now, and how they want to live.
          </p>
          <p className="text-xl opacity-95 max-w-3xl mx-auto">
            Financial wellness shouldn't feel like homework. It should feel like leveling up in your favorite game, chatting with a trusted friend, and watching your dreams become achievable goals.
          </p>
        </section>

        {/* CTA Section */}
        <section className="max-w-5xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">Ready to Start Your Journey?</h2>
          <p className="text-xl text-gray-700 mb-10">
            Join thousands of young adults who are taking control of their financial future with Finible.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <button
              onClick={() => setCurrentPage('app')}
              className="bg-gradient-to-r from-finible-teal to-finible-orange text-white px-12 py-5 rounded-xl text-xl font-bold hover:shadow-xl hover:scale-105 transition-all"
            >
              Talk to Sam Now
            </button>
            <button
              onClick={() => setCurrentPage('features')}
              className="bg-white border-2 border-finible-teal text-finible-teal px-12 py-5 rounded-xl text-xl font-bold hover:bg-finible-teal hover:text-white transition-all"
            >
              Explore Features
            </button>
          </div>
        </section>
      </div>
    </div>
  );

  // App Dashboard Page - AI Voice Coach
  const AppPage = () => <FinVoiceCoach />;

  // Render appropriate page
  const renderPage = () => {
    switch(currentPage) {
      case 'home': return <HomePage />;
      case 'features': return <FeaturesPage />;
      case 'pricing': return <PricingPage />;
      case 'about': return <AboutPage />;
      case 'app': return <AppPage />;
      default: return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      {renderPage()}
    </div>
  );
};

export default Finible;
