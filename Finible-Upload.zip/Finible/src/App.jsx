import Finible from './Finible'

function App() {
  return <Finible />
}

export default App